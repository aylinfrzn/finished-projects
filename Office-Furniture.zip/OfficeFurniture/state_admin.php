<?php
include("includes/header.php");
?>
<br/><br/><br/><tr><span style="color: red;"> شما ادمین سایت هستید</span> </tr> <br/><br/><br/>
<?php
include("includes/footer.php");
?>