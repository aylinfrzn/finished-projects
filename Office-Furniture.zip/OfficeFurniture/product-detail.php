<?php
include("includes/header.php");
?>
<link rel="stylesheet" href="styles/style.css">


 <div class="product-detail-container">
        <div class="product-detail">
            <div class="image">
                <img src="images\products\office-couch13.jpg" alt="محصولات">
            </div>
            <div class="details">
                <h1>نام محصول</h1>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce vel dapibus quam. Aenean sit amet
                    velit nec tortor tincidunt luctus. Vivamus pharetra turpis ut dui facilisis, vel tincidunt orci
                    placerat.</p>
                <p class="price">500.000 T</p>
                <a href="#" class="btn-buy">افزودن به سبد</a>
                <div class="extra-details">
                    <h2>ویژگی های محصول</h2>
                    <ul>
                        <li>ویژگی</li>
                        <li>ویژگی</li>
                        <li>ویژگی</li>
                        <li>ویژگی</li>
                    </ul>
                </div>
            </div>
        </div>
</div>

<?php
include("includes/footer.php");
?>