<?php
include("includes/header.php");
if(!(isset($_SESSION["state_login"]) && $_SESSION["state_login"]===true)){
?>
<link rel="stylesheet" href="styles/style.css">


<script type="text/javascript">
	location.replace("index.php");
</script>

<?php
}

$proID=$_POST['proID'];
$proName=$_POST['proName'];
$proQty=$_POST['proQty'];
$proPrice=$_POST['proPrice'];
$totalPrice=$_POST['totalPrice'];

$realname=$_POST['realname'];
$email=$_POST['email'];

$mobile=$_POST['mobile'];
$address=$_POST['address'];

$username=$_SESSION['username'];

$link=mysqli_connect("localhost","admin123","admin123","office_db");
if(mysqli_connect_errno())
	exit("<h3 class='action-message'>خطا با شرح ریز رخ داده است:" . mysqli_connect_error() . "</h3>");
$query="INSERT INTO orders
(id,
username,
orderdate,
proID,
proQty,
proPrice,
mobile,
address,
trackCode,
state) VALUES
('0',
'$username',
'".date('y-m-d')."',
'$proID',
'$proQty',
'$proPrice',
'$mobile',
'$address',
'000000000000000000000000',
'0')";
/*
0 تحت بررسی
1 آماده برای ارسال
2 ارسال شده
3 سفارش لغو شده است
*/
if(mysqli_query($link,$query)===true){
	echo("<h4 class='action-message' style='color:green;'><br/><br/><br/></br><b>سفارش شما با موفقیت در سامانه ثبت شد</b></h4>");
	
	echo("<h4 class='action-message' style='color:black;'></br><b>کاربر گرامی آقا/خانم $realname</b></h4>");
	
	echo("<h4 class='action-message' style='color:black;'></br><b>محصول $proName با کد $proID به تعداد/مقدار $proQty با قیمت پایه $proPrice ريال را سفارش داده اید</b></h4>");
	
	echo("<h4 class='action-message' style='color:red; '></br><b>مبلغ قابل پرداخت برای سفارش ثبت شده $totalPrice ريال است</b></h4>");
	 
	echo("<h4 class='action-message' style='color:blue;'></br><b>پس از بررسی سفارش و تایید آن با شما تماس گرفته خواهد شد</b></h4>");
	
	echo("<h4 class='action-message' style='color:blue;'></br><b>محصول خریداری شده ار طریق پست جمهوری اسلامی ایران طبق آدرس درج شده ارسال خواهد شد</b></h4>");
	
	echo("<h4 class='action-message' style='color:blue;'></br><b>در هنگام تحویل گرفتن محصول آن را بررسی و ار صحت و سالم بودن آن اطمینان حاصل کنید سپس مبلغ کالا را طبق فاکتور ارایه شده </br>به مامور پست تحویل دهید</b><br/><br/><br/></h4>");
	$query = "UPDATE products SET proQty=proQty-'$proQty' WHERE proID='$proID'";
	$result = mysqli_query($link,$query);
	
}
else
{
	echo("<h4 class='action-message' style='color:red;'></br><b>خطا در ثبت سفارش</b></h4>");
	if($proQty==0 || $proQty=="")
	   echo("<h4 class='action-message' style='color:brown;'></br><b>مقدار درخواستی محصول وارد نشده است</b></h4>");
	if($mobile<11)
       echo("<h4 class='action-message' style='color:brown;'></br><b>شماره موبایل به درستی وارد نشده است</b></h4>");
	if($address<15)
	   echo("<h4 class='action-message' style='color:brown;'></br><b>ادرس موزد نظر یه درستی وارد نشده است</b></h4>");
}
mysqli_close($link);
?>
<?php
include("includes/footer.php");
?>