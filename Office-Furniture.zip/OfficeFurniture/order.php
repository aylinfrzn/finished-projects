<?php
include("includes/header.php");
?>
<link rel="stylesheet" href="styles/style.css">
<!-- <link rel="stylesheet" href="styles/order-style.css"> -->
<?php
if (isset($_SESSION["state_login"]) && $_SESSION["state_login"] === true && $_SESSION["user_type"] === "admin") {
    ?>

<script type="text/javascript">
    location.replace("state_admin.php");
</script>

<?php
}
?>

<?php
$link = mysqli_connect("localhost", "admin123", "admin123", "office_db");
if (mysqli_connect_errno()) {
    exit("<h3 class='action-message'> خطا با شرح ریز رخ داده است: " . mysqli_connect_error() . "</h3>");
}
$proID = 0;

if (isset($_GET['id'])) {
    $proID = $_GET['id'];
}

if (!(isset($_SESSION["state_login"]) && $_SESSION["state_login"] === true)) {
    ?>
    <h4 class='action-message'>برای خرید پستی محصول انتخاب شده باید وارد سایت شوید  </h4>
    <h4 class='action-message'> در صورتی که عضو فروشگاه هستید برای ورود <a href="login.php" style="color:#e60000">اینجا</a>
    کلیک کنید و در صورتی که عضو نیستید برای ثبت نام در سایت 
    <a href="signin.php" style="color:#e60000">اینجا</a>
    کلیک کنید</h4>

<?php
    include("includes/footer.php");
    ?>

<?php
    exit();
}
?>

<?php
$query = "SELECT * FROM products WHERE proID='$proID'";
$result = mysqli_query($link, $query);
?>

<form name="order" action="action_order.php" method="POST">
    <div class="flex-container">
        <div class="flex-item">
            <?php
            if ($row = mysqli_fetch_array($result)) {
            ?>
            <div class="form-section">
                <div class="form-group">
                    <label>کد کالا</label>
                    <input type="text" id="proID" name="proID" value="<?php echo($proID); ?>" readonly/>
                </div>
                <div class="form-group">
                    <label>نام کالا</label>
                    <input class="textbox" type="text" id="proName" name="proName" value="<?php echo($row['proName']); ?>" readonly/>
                </div>
                <div class="form-group">
                    <label>تعداد یا مقدار درخواستی</label>
                    <input type="text" id="proQty" name="proQty" onkeypress="return onlyNumberKey(event)" onchange="calc_price();"/>
                </div>
                <div class="form-group">
                    <label>قیمت واحد کالا</label>
                    <input type="text" id="proPrice" name="proPrice" value="<?php echo($row['proPrice']); ?>" readonly/>
                </div>
                <div class="form-group">
                    <label>قیمت قابل پرداخت</label>
                    <input type="text" id="totalPrice" name="totalPrice" value="0" readonly/>
                </div>

                <?php
                $query = "SELECT * FROM users WHERE username='{$_SESSION['username']}'";
                $result = mysqli_query($link, $query);
                $user_row = mysqli_fetch_array($result);
                ?>

                <div class="form-group">
                    <label>نام خریدار</label>
                    <input type="text" id="realname" name="realname" value="<?php echo($user_row['realname']); ?>" readonly/>
                </div>
                <div class="form-group">
                    <label>پست الکترونیکی</label>
                    <input type="text" name="email" id="email" value="<?php echo($user_row['email']); ?>" readonly/>
                </div>
                <div class="form-group">
                    <label>شماره تلفن همراه</label>
                    <input type="text" onkeypress="return onlyNumberKey(event)" maxlength="11" name="mobile" id="mobile" value="09"/>
                </div>
                <div class="form-group">
                    <label>آدرس دقیق پستی</label>
                    <textarea name="address" id="address" cols="30" rows="6"></textarea>
                </div>
                <input class="btn"type="submit" value="خرید محصول" onClick="check_input();"/>
            </div>
        </div>

        <div class="flex-item">
            <div class="product-preview">
                <h5><?php echo($row['proName']) ?></h5>
                <img width="300px" height="300px" src="images/products/<?php echo($row['proImage']); ?>"/>
                <h6>قیمت: <?php echo($row['proPrice']) ?>&nbsp;ریال</h6>
                <h6>تعداد موجودی:  <?php echo($row['proQty']); ?></h6>
                <h6>توضیحات: 
                <?php
                $count = strlen($row['proDetails']);
                echo(substr($row['proDetails'], 0, (int)($count / 4)));
                ?>
                ...</h6>
            </div>
        </div>
    </div>
</form>

<script>
    function onlyNumberKey(evt) {
        var ASCIICode = (evt.which) ? evt.which : evt.keyCode;
        return !(ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57));
    }

    function calc_price() {
        var proQty = <?php echo($row['proQty']); ?>;
        var price = document.getElementById('proPrice').value;
        var count = document.getElementById('proQty').value;
        var totalPrice;

        if (count > proQty) {
            alert('تعداد موجودی انبار کمتر از درخواست شما است!!');
            document.getElementById('proQty').value = 0;
            count = 0;
        }
        totalPrice = (count == 0 || count == "") ? 0 : count * price;
        document.getElementById('totalPrice').value = totalPrice;
    }

    function check_input() {
        var r = confirm("از صحت اطلاعات وارد شده اطمینان دارید؟");
        if (r) {
            var validation = true;
            var count = document.getElementById('proQty').value;
            var mobile = document.getElementById('mobile').value;
            var address = document.getElementById('address').value;

            validation = !(count == 0 || count == "" || mobile.length < 11 || address.length < 15);

            if (validation) {
                document.order.submit();
            } else {
                alert('برخی از ورودی های فرم سفارش محصول به درستی پر نشده است');
            }
        }
    }
</script>
<?php
	}
?>
<?php
include("includes/footer.php");
?>
