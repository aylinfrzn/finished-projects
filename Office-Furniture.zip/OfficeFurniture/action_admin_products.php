<?php
include("includes/header.php");
if(!(isset($_SESSION["state_login"]) && $_SESSION["state_login"]===true && $_SESSION["user_type"]==="admin"))
{
	?>
<link rel="stylesheet" href="styles/style.css">


<script type="text/javascript">
	
		location.replace("index.php");
	
</script>


<?php
	
	}
?>

<?php
if(!isset($_GET['action']))
{
if(isset($_POST['proID']) && !empty($_POST['proID']) &&
  isset($_POST['proName']) && !empty($_POST['proName']) &&
  isset($_POST['proCat']) && !empty($_POST['proCat']) &&
  isset($_POST['proQty']) && !empty($_POST['proQty']) &&
  isset($_POST['proPrice']) && !empty($_POST['proPrice']) &&
  isset($_POST['proDetails']) && !empty($_POST['proDetails']))
{
	$proID=$_POST['proID'];
	$proName=$_POST['proName'];
    $proCat=$_POST['proCat'];
	$proQty=$_POST['proQty'];
	$proPrice=$_POST['proPrice'];
	$proImage=basename($_FILES["proImage"]["name"]);
	$proDetails=$_POST['proDetails'];
}else
	exit("<h2 class='action-message'>برخی از فیلد ها مقدار دهی نشده اند</h2>");
}
$link=mysqli_connect("localhost","admin123","admin123","office_db");
if(mysqli_connect_errno())
	exit("<h2> خطایی با شرح زیر رخ داده است:".mysqli_connect_error()."</h2>");
if(isset($_GET['action']))
{
	$id=$_GET['id'];
	switch($_GET['action'])
	{
		case 'EDIT':
			$proID=$_POST['proID'];
         	$proName=$_POST['proName'];
             $proCat=$_POST['proCat'];
	        $proQty=$_POST['proQty'];
	        $proPrice=$_POST['proPrice'];
			$proDetails=$_POST['proDetails'];
			$query="UPDATE products SET
			proID='$proID',
			proName='$proName',
            proCat='$proCat',
			proQty='$proQty',
			proPrice='$proPrice',
			proDetails='$proDetails'
			WHERE proID='$id'";
			if(mysqli_query($link,$query)===true)
				echo("<p class='action-message' style='color:green;'><b>محصول مورد نظر با موفقیت ویرایش شد</b></p>");
			else
				echo("<p class='action-message' style='color:red;'><b>محصول مورد نظر ویرایش نشد</b></p>");
            break;
		case 'DELETE':
			$query="SELECT proImage FROM products WHERE proID='$id'";
			$result=mysqli_query($link,$query);
			$row=mysqli_fetch_array($result);
			$proImage=$row['proImage'];
			$query="DELETE FROM products WHERE proID='$id'";
			if(mysqli_query($link,$query)===true)
			{
				echo("<p style='color:green;' class='action-message'><b>محصول انتخاب شده با موفقیت حذف شد</b></p>");
			$file=unlink("images/products/".$proImage);
				if(!$file)
			echo("<p class='action-message' style='color:red;'><b>خطا در قطع ارتباط با تصویر</b></p>");
            else
				echo("<p class='action-message' style='color:green;'><b>تصویر محصول حذف شد</b></p>");
			}
				else
				echo("<p class='action-message' style='color:red;'><b> خطا در حذف محصول</b></p>");
			break;
	}
	mysqli_close($link);
	include("includes/footer.php");
	exit();
}
$target_dir="images/products/";
$target_file=$target_dir.basename($_FILES["proImage"]["name"]); 
$uploadOk=1;
$imagefileType=pathinfo($target_file,PATHINFO_EXTENSION);

$check=getimagesize($_FILES["proImage"]["tmp_name"]);
if($check !==false)
{
	echo("<h3>پرونده انتخابی یک تصویر از نوع - ".$check["mime"]."است</h3>");
	$uploadOk=1;
}
else
{
	echo("<h3 class='action-message'>پرونده انتخابی یک تصویر نیست </h3>");
	$uploadOk=0;
}
if(file_exists($target_file))
{
	echo("<h3 class='action-message'>پرونده ای با همین نام در سرویس دهنده میزبان وجود دارد </h3>");
	$uploadOk=0;
}
if($_FILES["proImage"]["size"] > (500*1024))
{
	echo("<h3 class='action-message'>اندازه پرونده انتخابی بیشتر از 500 کیلوبایت است </h3>");
    $uploadOk=0;
}

$imagefileType != strtolower($imagefileType);
if($imagefileType !="jpg" && $imagefileType !="png" && $imagefileType !="jpeg" && $imagefileType !="gif")
{
	echo("<h3 class='action-message'>فقط پسوند های jpg,png,jpeg,gif برای پرونده مجاز هستند </h3>");
	$uploadOk=0;
}
if($uploadOk==0)
{
	echo("<h3 class='action-message'>پرونده انتخاب شده به سرویس دهنده میزبان ارسال نشد </h3>");
}
else
{
	if(move_uploaded_file($_FILES["proImage"]["tmp_name"],$target_file))
	{
		echo("<h3 class='action-message'>پرونده".basename($_FILES["proImage"]["name"])."با موفقیت به سرویس دهنده میزبان انتقال یافت </h3>");
	}
	else
	{
    echo("<h3 class='action-message'>خطا در ارسال پرونده به سرویس دهنده میزبان رخ داده است </h3>");
	}
}
if($uploadOk==1)
{
	$query="INSERT INTO products(proID,proName,proCat,proQty,proPrice,proImage,proDetails)VALUES
	('$proID','$proName','$proCat','$proQty','$proPrice','$proImage','$proDetails')";
	
	if(mysqli_query($link,$query)===true)
		echo("<p class='action-message' style='color:green;'><b> کالا با موفقیت به انبار اضافه شد </b></p>");
	else
		echo("<p style='color:red;' class='action-message'><b> خطا در ثبت مشخصات کالا در انبار </b></p>");
   }else
		echo("<p style='color:red;' class='action-message'><b> خطا در ثبت مشخصات کالا در انبار </b></p>");

	mysqli_close($link);

	include("includes/footer.php");
?>