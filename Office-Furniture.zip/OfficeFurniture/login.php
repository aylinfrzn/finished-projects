<?php
include("includes/header.php");
if(isset($_SESSION["state_login"]) && $_SESSION["state_login"]===true){
	?>
<script type="text/javascript">
	location.replace("index.php");
</script>
	<?php
}
?>
<link href="styles/style.css" rel="stylesheet"/>

<section class="login-section">
<div class="login">
    <h1>ورود</h1>
    <form name="login" action="action_login.php" method="POST">
      <div class="login-info">
        <input name="username" type="text" placeholder="نام کاربری" required>
      </div>
      <div class="login-info">
        <input name="password" type="password" placeholder="رمزعبور" required>
      </div>
      <input type="submit" class="btn-login" value="ورود"/>
    </form>
    <div class="login-links">
      <p>حساب کاربری ندارید؟<a href="signin.php">ثبت نام کنید</a></p>
      <p><a href="#">فراموشی رمزعبور</a></p>
    </div>
  </div>
  </section>

<?php
include("includes/footer.php");
?>