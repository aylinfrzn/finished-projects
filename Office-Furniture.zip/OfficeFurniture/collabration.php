<?php
include("includes/header.php");
?>
<link rel="stylesheet" href="styles/style.css">

<section class="why-collaborate">
    <h2>چرا با ما همکاری کنید؟</h2>

    <div class="features">
        <div class="feature">
            <img src="icons/icon-growth.png" alt="رشد">
            <h3>رشد مشترک</h3>
            <p>با همکاری ما، به بازارهای جدید دسترسی پیدا کنید و برند خود را تقویت کنید.</p>
        </div>

        <div class="feature">
            <img src="icons/icon-social-network.png" alt="شبکه">
            <h3>شبکه گسترده</h3>
            <p>از شبکه ارتباطی ما بهره‌مند شوید و همکاری‌های بیشتری ایجاد کنید.</p>
        </div>

        <div class="feature">
            <img src="icons/icon-innovation.png" alt="نوآوری">
            <h3>نوآوری و خلاقیت</h3>
            <p>همکاری ما فرصت‌هایی برای پروژه‌های خلاقانه و نوآورانه فراهم می‌کند.</p>
        </div>
    </div>
</section>

        <!-- Partners Section -->
<section class="partners">
    <h2>برندهایی که با ما همکاری کرده‌اند</h2>

    <div class="partner-logos">
        <img src="images/vezarat-oloom.jpg" alt="وزارت علوم">
        <img src="images/saypa.jpg" alt="سایپا">
        <img src="images/shahrdari.jpg" alt="شهرداری">
        <img src="images/tehran-university.jpg" alt="دانشگاه تهران">
        <img src="images/petro-pars.jpg" alt="پتروپارس">
        <img src="images/sherkat-naft.jpg" alt="پتروپارس">
        <img src="images/irib.jpg" alt="پتروپارس">
        <img src="images/irankhodro.jpg" alt="پتروپارس">

    </div>
</section>

<?php
include("includes/footer.php");
?>