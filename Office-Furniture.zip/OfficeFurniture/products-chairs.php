<?php
include("includes/header.php");
?>
<link rel="stylesheet" href="styles/style.css">
<?php
$link=mysqli_connect("localhost","admin123","admin123","office_db");
if(mysqli_connect_errno())
	exit("خطا با شرح ریز رخ داده است:".mysqli_connect_error());
$query="SELECT * FROM products WHERE proCat=1 ";
$result=mysqli_query($link,$query);
?>
<br/><br/><br/>
<table class="container" style="width: 100%; border-style: none; border-spacing: 17px;">
<tr>
<?php
$counter=0;
while($row=mysqli_fetch_array($result)){
	$counter++;
?>
<td  class="product" style="border-style:none; vertical-align: top;width: 24%;">
	<h3><?php echo($row['proName'])?></h3>
	<a  href="products_details.php?id=<?php echo($row['proID'])?>">
	<center>
	<img src="images/products/<?php echo($row['proImage'])?>" width="250px" height="130px"/>
	</center>
	</a>
    <!-- <h6> دسته بندی:
        <?php 
        $CatName=$row['proCat'];
        switch($CatName){
        case 1:
            echo("صندلی");
            break;
        case 2:
            echo("میز");
            break;
        case 3:
            echo("مبلمان");
            break;
        default:
            echo "معتبر نیست.";
            break;
        }
        ?>
        </h6> -->
	<p class="price"> قیمت: <?php echo($row['proPrice'])?>&nbsp;ریال </p>
    <!-- <p>تعداد موجودی: <span style="color: red;"><?php echo($row['proQty'])?></span></p> -->
    <!-- <p>توضیحات: <span style="color: green; line-break: auto;"><?php echo(substr($row['proDetails'],0,50))?>...</span></p> -->
    <button><b><a href="products_details.php?id=<?php echo($row['proID'])?>" style="text-decoration: none;">توضیحات تکمیلی و خرید</a></b></button>
</td>
<?php
		if($counter%4==0)
			echo("</tr><tr>");
	}
if($counter%4!=0)
	echo("</tr>");
?>

</table>
<br/><br/><br/>
<?php
include("includes/footer.php");
?>