<?php
include("includes/header.php");
?>
<link rel="stylesheet" href="styles/style.css">

<?php
if(isset($_POST['username']) && !empty($_POST['username']) &&
   isset($_POST['password']) && !empty($_POST['password']))
{
	$username=$_POST['username'];
    $password=$_POST['password'];
}else
	exit("<h3 class='action-message'>برخی از فیلد ها مقدار دهی نشده است </h3>");

$link=mysqli_connect("localhost", "admin123", "admin123", "office_db");
if(mysqli_connect_errno())
	exit("<h3 class='action-message'> خطا با شرح ریز رخ داده است: " . mysqli_connect_error() . "</h3>");

$query="SELECT * FROM users WHERE username='$username' AND password='$password'";
$result=mysqli_query($link,$query);

$row=mysqli_fetch_array($result);
if($row){
	$_SESSION["state_login"]=true;
	$_SESSION["realname"]=$row['realname'];
	$_SESSION["username"]=$row['username'];
	if($row["type"]==0)
		$_SESSION["user_type"]="public";
	elseif($row["type"]==1){
		$_SESSION["user_type"]="admin";
	?>
	<script type="text/javascript">
	location.replace("admin_products.php");
</script>
<?php
	}
	echo("<h2 class='action-message'><strong>{$row['realname']} به فروشگاه نیلپر خوش آمدید </strong></h2>");
}
else
	echo("<h2 class='action-message'> نام کاربری یا کلمه رمز عبور یافت نشد </h2>");
mysqli_close($link);
?>

<?php
include("includes/footer.php");
?>