<?php
include("includes/header.php");?>
<?php
if(!(isset($_SESSION["state_login"]) && $_SESSION["state_login"]===true && $_SESSION["user_type"]==="admin"))
{
?>	
<link rel="stylesheet" href="styles/style.css">

<script type="text/javascript">
		location.replace("index.php");
</script>
	

<?php
}
$link=mysqli_connect("localhost","admin123","admin123","office_db");
if(mysqli_connect_errno())
exit("<h3  class='action-message'> خطایی با شرح زیر رخ داده است:" . mysqli_connect_error() . "</h3>");
$url = $proID = $proName = $proCat = $proQty = $proPrice = $proImage = $proDetails = "";
$btn_caption = "افزودن کالا";
if(isset($_GET['action']) && $_GET['action']=='EDIT'){
	$id=$_GET['id'];
	$query="SELECT * FROM products WHERE proID='$id'";
	$result=mysqli_query($link,$query);
	if($row=mysqli_fetch_array($result))
	{
		$proID=$row['proID'];
		$proName=$row['proName'];
		$proQty=$row['proQty'];
        $proCat=$row['proCat'];
		$proPrice=$row['proPrice'];
		$proImage=$row['proImage'];
		$proDetails=$row['proDetails'];
		$url="?id=$proID&action=EDIT";
		$btn_caption="ویرایش کالا";
	}
}
?>
<link rel="stylesheet" href="styles/style.css">

<form name="admin_products" action="action_admin_products.php <?php if(!empty($url))echo($url);?>" method="POST" enctype="multipart/form-data" >
	<table class="add-product-table">
		<tr>
			<td style="width:25%"> کد کالا </td>
			<td style="width:75%"><input type="text" id="proID" name="proID" value="<?php echo($proID)?>" /></td>
		</tr>
		<tr>
			<td> نام کالا </td>
			<td><input type="text" style="text-align:right;" id="proName" name="proName" value="<?php echo($proName)?>"/></td>
		</tr>
		<tr>
			<td> موجودی کالا </td>
			<td><input type="text" style="text-align:left;" id="proQty" name="proQty" value="<?php echo($proQty)?>"/></td>
		</tr>
        <tr>
			<td> دسته بندی </td>
			<td>
            	<select id="proCat" name="proCat">
            		<option value="1">صندلی</option>
            		<option value="2">میز</option>
            		<option value="3">مبلمان</option>
        		</select>
            </td>
		</tr>
		<tr>
			<td> قیمت کالا </td>
			<td><input type="text" style="text-align:left;" id="proPrice" name="proPrice" value="<?php echo($proPrice)?>"/><span style="color: Black; font-size: 14px;">&nbsp;&nbsp;&nbsp;ريال</span></td>
		</tr>
		<tr>
			<td> اپلود تصویر کالا </td>
			<td><input type="file" style="text-align:left;" id="proImage" name="proImage" size="30"/>
			<?php if(!empty($proImage))
	        echo("<img src='images/products/$proImage' width='60' height='70' />"); ?>
	</td>
		</tr>
		<tr>
			<td> کالا </td>
			<td><textarea style="font-family: tahoma;text-align: right; background: hsla(0, 0.00%, 0.00%, 0.50);
	border:2px hsla(0,0%,100%,0.50); border-radius:6px; box-shadow: 1px 0px 0px 5px hsla(0, 0.00%, 0.00%, 0.50) ;" id="proDetails" name="proDetails" cols="45" rows="10" wrap="virtual"><?php echo($proDetails)?></textarea>
		</tr>
		<tr>
			<td><br/><br/></td>
			<td>
				<input class="btn" type="submit" value="<?php echo($btn_caption)?>"/> &nbsp;&nbsp;&nbsp;
				<input class="btn" type="reset" value="جدید" />
			</td>
		</tr>
	</table>
</form>

<?php
$query="SELECT * FROM products";
$result=mysqli_query($link,$query);
?>

<table class="admin-product-table">
	<tr>
		<td>کد کالا</td>
		<td>نام کالا</td>
        <td>دسته بندی</td>
		<td>موجودی کالا</td>
		<td>قیمت کالا</td>
		<td>تصویر کالا</td>
		<td>ابزار مدیریتی</td>
	</tr>

	<?php
	while($row=mysqli_fetch_array($result)){
	?>

	<tr>
		<td><?php echo($row['proID'])?></td>
		<td><?php echo($row['proName'])?></td>
        <td>
			<?php 
        	$CatName = $row['proCat'];
        	switch($CatName){
        	case 1:
            	echo("صندلی");
            	break;
        	case 2:
            	echo("میز");
            	break;
        	case 3:
            	echo("مبلمان");
            	break;
        	default:
            	echo "معتبر نیست.";
            	break;
        	}
        	?>
		</td>
        <td style="text-align: center"><?php echo($row['proQty'])?></td>

        <td><?php echo($row['proPrice'])?>&nbsp; تومان </td>
        
		<td><img src="images/products/<?php echo($row['proImage'])?>" width="100px" height="80px" /></td>
        
		<td>
        	<a href="action_admin_products.php?id=<?php echo($row['proID'])?>&action=DELETE">حذف</a>
        	&nbsp;&nbsp;
        	<a href="admin_products.php?id=<?php echo($row['proID'])?>&action=EDIT">ویرایش</a>
        </td>
	</tr>

	<?php
	}
	?>

</table>
<br/><br/><br/>
<?php
include("includes/footer.php");
?>