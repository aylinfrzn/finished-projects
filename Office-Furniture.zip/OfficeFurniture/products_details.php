<?php
include("includes/header.php");
?>
<link rel="stylesheet" href="styles/style.css">
<?php
	$link=mysqli_connect("localhost","admin123","admin123","office_db");
  if(mysqli_connect_errno())
	exit("خطا با شرح ریز رخ داده است:".mysqli_connect_error());
$proID=0;
if(isset($_GET['id']))
	$proID=$_GET['id'];
$query="SELECT * FROM products WHERE proID='$proID'";
$result=mysqli_query($link,$query);
?>
<table class="product-detail-container">
<tr >
<?php
	if($row=mysqli_fetch_array($result)){
?>
<td class="product-detail">
    <div class="image">
	<img src="images/products/<?php echo($row['proImage'])?>"/>
    </div>
    <div class="details">
    <h1><?php echo($row['proName'])?></h1>
    <p>دسته بندی: <?php 
        $CatName=$row['proCat'];
        switch($CatName){
        case 1:
            echo("صندلی");
            break;
        case 2:
            echo("میز");
            break;
        case 3:
            echo("مبلمان");
            break;
        default:
            echo "معتبر نیست.";
            break;
        }
        ?></p>
    
	<p>قیمت: <?php echo($row['proPrice'])?>&nbsp;ریال</p> 
    
    <p> تعداد موجودی: <span><?php echo($row['proQty'])?></span></p>
    
    <div class="extra-details" >
    <h2> توضیحات: <span><?php echo($row['proDetails'])?></span></h2>
    </div>
    
    
    <h5><b><a class="btn-buy" href="order.php?id=<?php echo($row['proID'])?>">سفارش و خرید پستی</a></b></h5>
</div></td>
<?php
    	}
?>
	</tr>
</table>
<?php
include("includes/footer.php");
?>