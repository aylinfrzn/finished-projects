<?php
include("includes/header.php");
if(isset($_POST['username']) && !empty($_POST['username']) &&
   isset($_POST['realname']) && !empty($_POST['realname']) &&
   isset($_POST['email']) && !empty($_POST['email']) &&
   isset($_POST['password']) && !empty($_POST['password']) &&
   isset($_POST['repassword']) && !empty($_POST['repassword'])
)
{
$username=$_POST['username'];
$realname=$_POST['realname'];
$password=$_POST['password'];
$repassword=$_POST['repassword'];
$email=$_POST['email'];
}
else
	exit("<h2 class='action-message'>تمام فیلد ها مقدار دهی نشده است</h2>");
if($password != $repassword)
	exit("<h2 class='action-message'>رمز عبور و تکرار رمز عبور مطابقت ندارد</h2>");
if(filter_var($email,FILTER_VALIDATE_EMAIL)=== false)
	exit("<h2 class='action-message'>پست الکترونیکی وارد شده صحیح نمیباشد</h2>");

$link=mysqli_connect("localhost","admin123","admin123","office_db");
if(mysqli_connect_errno())
	exit("<h2 class='action-message'> خطا با شرح ریز رخ داده است:" . mysqli_connect_error() . "</h2>");
$query="INSERT INTO users(username,realname,password,email,type) VALUES('$username','$realname','$password','$email','0')";
if(mysqli_query($link,$query)===true)
	echo("<h2 class='action-message'>" . $realname ." گرامی عضویت شما با نام کاربری " . $username . " در فروشگاه با موفقیت انجام شد </h2>");
else
	echo("<h2 class='action-message'> عضویت شما در فروشگاه انجام نشد</h2>");
mysqli_close($link);
?>
<link rel="stylesheet" href="styles/style.css">



<?php
include("includes/footer.php");
?>