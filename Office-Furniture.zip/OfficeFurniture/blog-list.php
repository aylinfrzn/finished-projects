<?php
include("includes/header.php");
?>
<link rel="stylesheet" href="styles/style.css">
 <br/>
    <div class="blog-container">
        <div class="blog-list">
            <h3>اصول ارگونومی متحول کننده است!</h3>
            <p>ارگونومی در محیط کار: کلید سلامت و بهره‌وری

                ارگونومی (Ergonomics) به علم طراحی و تنظیم محیط کار برای هماهنگی با نیازها و محدودیت‌های انسان گفته
                می‌شود. این علم نقش
                مهمی در بهبود سلامت...</p> <br />
            <a class="blog-btn" href="blog1.php">بیشتر بخوانید</a>
        </div>
        <img src="images/ergonomics.jpg" id="pic">
    </div>

    <div class="blog-container">
        <div class="blog-list">
            <h3>چگونه انتخاب مبلمان اداری مناسب بهره‌وری شما را افزایش می‌دهد؟</h3>
            <p>محیط کار تاثیر مستقیمی بر سلامت جسمانی، روحیه و بهره‌وری کارکنان دارد. انتخاب مبلمان اداری مناسب یکی از مهم‌ترین عواملی است که می‌تواند به بهبود عملکرد افراد و کاهش خستگی کمک کند...</p> <br />
            <a class="blog-btn" href="blog2.php">بیشتر بخوانید</a>
        </div>
        <img src="images/blog2.jpg" id="pic">
    </div>
    

    <div class="blog-container">
        <div class="blog-list">
            <h3>اهمیت زیبایی‌شناسی در کنار کارایی در طراحی محیط‌های اداری</h3>
            <p>محیط کاری نقش مهمی در ایجاد انگیزه، افزایش بهره‌وری و ارتقای روحیه کارکنان دارد. در گذشته، تمرکز اصلی در طراحی دفاتر بر کارایی و عملکرد بود، اما امروزه زیبایی‌شناسی نیز به عنوان یکی از عناصر کلیدی طراحی محیط‌های اداری مطرح شده است...</p> <br />
            <a class="blog-btn" href="blog3.php">بیشتر بخوانید</a>
        </div>
        <img src="images/beautiful-office.jpg" id="pic">
    </div>
    <br/>


<br/>
<?php
include("includes/footer.php");
?>