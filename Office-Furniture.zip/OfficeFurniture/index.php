<?php
include("includes/header.php");
?>

<link rel="stylesheet" href="styles/style.css">

<!-- /////////////    HERO     //////////////////////////////////////////////////////////////////////////// -->
<div class="hero">
    <img class="hero-img" src="images/office-space.jpg" alt="hero" />
</div>

<!-- /////////////    WHY US   //////////////////////////////////////////////////////////////////////////// -->
<div class="container grid grid--4culs">
    <div>
        <p class="feature-title" style="font-size: 5rem; margin-top: 2.4rem;
            margin-bottom: 3.2rem;">چرا نیلپر؟</p>
        <a href="about-us.php" class="btn">بیشتر بدانید</a>
    </div>

    <div>
        <img class="feature-icon" src="icons/icon-office-chair.png">
        <p class="feature-title">طراحی ارگونومیک و مدرن</p>
        <p class="feature-text">
            تمامی محصولات
            بر اساس
            اصول علمی برای افزایش بهره‌وری طراحی شده‌اند تا راحتی، زیبایی و سلامت را به محیط کاری شما می‌آورند. </p>
    </div>

    <div>
        <img class="feature-icon" src="icons/icon-phone.png">
        <p class="feature-title">خدمات پس از فروش حرفه‌ای</p>
        <p class="feature-text">
            تعهد ما به شما فقط به زمان خرید محدود نمی‌شود. تیم پشتیبانی ما همیشه آماده است تا در هر زمان، به شما
            خدمات ارائه دهد.
        </p>
    </div>

    <div>
        <img class="feature-icon" src="icons/icon-coin.png">
        <p class="feature-title">ارزش اقتصادی</p>
        <p class="feature-text">
            ما با ارائه محصولاتی با کیفیت و قیمت مناسب، بهترین انتخاب را برای سرمایه‌گذاری در محیط کاری شما فراهم
            می‌کنیم.
        </p>
    </div>

</div>

<!-- /////////////    CTA   //////////////////////////////////////////////////////////////////////////// -->
<section>
    <div class="container">
        <div class="cta">
            <div class="cta-text-box">
                <h2 class="heading-secondary">از جدیدترین اخبار مطلع شوید!</h2>
                <p class="cta-text">
                    برای مطلع شدن از تخفیف ها و جدیدترین محصولات ثبت نام کنید.
                </p>

                <form class="cta-form" action="#">
                    <div>
                        <label for="full-name">نام و نام خانوادگی</label>
                        <input id="full-name" type="text" placeholder="آیلین فرزانه" required />
                    </div>
                    <div>
                        <label for="emailaddress">آدرس ایمیل</label>
                        <input id="emailaddress" type="email" placeholder="me@example.com" style="direction: ltr;"
                            required />
                    </div>
                    <div class="select">
                        <label for="select-where">از کجا درباره ی ما شنیدید؟</label>
                        <select id="select-where" required>
                            <option value="">لطفا یک گزینه انتخاب کنید</option>
                            <option value="friends">دوستان و خانواده</option>
                            <option value="youtube">تبلیغات</option>
                            <option value="podcast">شرکت های همکار</option>
                            <option value="other">دیگر</option>
                        </select>
                    </div>
                    <a href="signin.php" class="btn form-btn">ثبت نام کنید</a>
                </form>
            </div>
            <div class="cta-img-box">
                <img src="images/cta-office2.jpg" />
            </div>
        </div>
    </div>
</section>

<?php
include("includes/footer.php");
?>