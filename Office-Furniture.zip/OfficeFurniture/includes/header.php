<!DOCTYPE html>
<?php
session_start();
?>
<html lang="fa">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>نیلپر</title>
    <link rel="stylesheet" href="styles/headerstyle.css">
    
</head>

<body dir="rtl">
    <header class="header">
        <nav class="nav-links">
            <ul>
            <?php
                        if (isset($_SESSION["state_login"]) && $_SESSION["state_login"]===true) 
                         {
                    ?>
                   <li class="menu-item"><a href="logout.php" class="menu-login" >خروج از سایت<?php echo(" ({$_SESSION["realname"]}) ") ?></a></li>
                    <?php
                         } 
                        else
                         { 
                    ?>  
							<li class="menu-item"><a href="login.php" class="menu-login" >ورود/ثبت‌نام</a></li>
                            
                    <?php
                         }
                    ?>
                <li class="menu-item">
                    <a href="products.php">محصولات</a>
                    <ul class="submenu">
                    <li><a href="products-chairs.php">صندلی</a></li>
                        <li><a href="products-desks.php">میز</a></li>
                        <li><a href="products-couch.php">مبلمان</a></li>
                    </ul>
                </li>
                <li class="menu-item"><a href="about-us.php">درباره ی ما</a></li>
                <li class="menu-item"><a href="collabration.php">همکاری با ما</a></li>
                <?php
				if(isset($_SESSION["state_login"]) && $_SESSION["state_login"]===true && $_SESSION["user_type"]=="admin"){
					?>
					<li class="menu-item"><a href="admin_products.php">مدیریت محصولات</a></li>
				<?php
				}
				?>
                <li class="menu-item"><a href="blog-list.php">وبلاگ</a></li>
                
            </ul>
        </nav>
        <div class="logo">
            <a href="index.php"><img src="images/logo_prev_ui.png" alt="Logo"></a>
        </div>
    </header>
    <br/><br/><br/><br/><br/>
