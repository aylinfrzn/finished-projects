<!-- /////////////    FOOTER   //////////////////////////////////////////////////////////////////////////// -->
    
<link rel="stylesheet" href="styles/footerstyle.css">
<footer>
    <div class="footer-container">
        <div class="footer-section">
            <h3>راهنما ها</h3>
            <ul>
                <li><a href="purchase-tutorial.php">راهنمای خرید از نیلپر</a></li>
                <li><a href="refund.php">رویه ی بازگرداندن کالا</a></li>
                <li><a href="purchase.php">راهنمای ثبت سفارش</a></li>
                <li><a href="payment-methods.php">شیوه های پرداخت</a></li>
                <li><a href="guaranty.php">شرایط گارانتی</a></li>
            </ul>
        </div>

        <div class="footer-section">
            <h3>ارتباط با ما</h3>
            <p>تهران – شهرک غرب – خیابان سپهر – خیابان گلبرگ سوم – خیابان شهید لطفعلی کردستانی (گلرخ) – پلاک 111</p>
            <a class="info" href="#">09388145967</a><br />
            <a class="info" href="021-82750">021-82750</a><br />
            <a class="info" href="info@nilper.com">info@nilper.com</a>
        </div>

        <div class="footer-section">
            <h3>مارا دنبال کنید</h3>
            <div class="social-icons">
                <ul>
                    <li><a href="privacy-policy.php">حفظ حریم شخصی</a></li>
                    <li><a href="common-questions.php">سؤالات متدوال</a></li>
                    <li><a href="terms-conditions.php">شرایط و قوانین</a></li> <br />
                </ul>
                <a href="https://www.facebook.com/my.profile/">
                    <img width="30" height="30" src="https://img.icons8.com/ios-glyphs/30/f4f4f4/facebook-new.png"
                        alt="facebook-new" />
                </a>
                <a href="https://api.whatsapp.com/send/?phone=%2B989370247258&text&type=phone_number&app_absent=0">
                    <img width="30" height="30" src="https://img.icons8.com/ios-glyphs/30/f4f4f4/whatsapp.png"
                        alt="whatsapp" />
                </a>
                <a
                    href="https://instagram.com/accounts/login/?next=https%3A%2F%2Fwww.instagram.com%2Fnilper.furniture%2F&is_from_rle">
                    <img width="30" height="30" src="https://img.icons8.com/ios-glyphs/30/f4f4f4/instagram-new.png"
                        alt="instagram-new" />
                </a>
                <a href="https://www.linkedin.com/company/nilper"><img width="30" height="30"
                        src="https://img.icons8.com/ios-glyphs/30/f4f4f4/linkedin.png" alt="linkedin" /></a>
            </div>
        </div>

        <div class="footer-section">
            <h3>گالری</h3>
        </div>

    </div>
    <div class="footer-bottom">
        <p>&copy; تمامی حقوق این وب سایت برای شرکت نیلپر محفوظ می باشد.</p>
    </div>
</footer>
</body>

</html>