<?php
include("includes/header.php");
?>
<link href="styles/style.css" rel="stylesheet"/>

<script type="text/javascript">
	  function check_empty()
	  {
			  var r=window.confirm("از صحت اطلاعات اطمینان دارید؟");
				  if(r ==true)
				  document.signin.submit();
	  }
</script>

<section class="login-section">
<div class="login">
  
    <h1>ثبت نام</h1>
    <form name="signin" action="action_signin.php" method="POST" >
      
    <div class="login-info">
        <input name="username" type="text" placeholder="نام کاربری" required>
      </div>

      <div class="login-info">
        <input name="realname" type="text" placeholder="نام واقعی" required>
      </div>
    
    <div class="login-info">
        <input name="email" type="email" placeholder="ایمیل" required>
      </div>

      <div class="login-info">
        <input name="password" type="password" placeholder="رمزعبور" required>
      </div>

       <div class="login-info">
        <input name="repassword" type="password" placeholder="تکرار رمزعبور" required>
      </div>

      <input type="submit" class="btn-login" onclick="check_empty();" value="ثبت نام" ></input>
      
      <input type="reset" class="btn-login" value="بازنشانی"></input>
    </form>

    <div class="login-links">
      <p>اگر حساب کاربری دارید <a href="login.php">وارد شوید</a></p>
    </div>

  </div>
  </section>

<?php
include("includes/footer.php");
?>