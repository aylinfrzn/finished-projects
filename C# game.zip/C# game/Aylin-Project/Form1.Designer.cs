﻿namespace Aylin_Project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lblPname = new System.Windows.Forms.Label();
            this.lblEname = new System.Windows.Forms.Label();
            this.lblGoodFor = new System.Windows.Forms.Label();
            this.lblBadFor = new System.Windows.Forms.Label();
            this.txtPname = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.txtEname = new System.Windows.Forms.TextBox();
            this.grpboxVitamin = new System.Windows.Forms.GroupBox();
            this.lblA = new System.Windows.Forms.Label();
            this.lblB = new System.Windows.Forms.Label();
            this.lblC = new System.Windows.Forms.Label();
            this.lblD = new System.Windows.Forms.Label();
            this.lblE = new System.Windows.Forms.Label();
            this.lblK = new System.Windows.Forms.Label();
            this.chkboxBTrue = new System.Windows.Forms.CheckBox();
            this.chkboxBFalse = new System.Windows.Forms.CheckBox();
            this.chkboxAFalse = new System.Windows.Forms.CheckBox();
            this.chkboxATrue = new System.Windows.Forms.CheckBox();
            this.chkboxCFalse = new System.Windows.Forms.CheckBox();
            this.chkboxCTrue = new System.Windows.Forms.CheckBox();
            this.chkboxDFalse = new System.Windows.Forms.CheckBox();
            this.chkboxDTrue = new System.Windows.Forms.CheckBox();
            this.chkboxEFalse = new System.Windows.Forms.CheckBox();
            this.chkboxETrue = new System.Windows.Forms.CheckBox();
            this.chkboxKFalse = new System.Windows.Forms.CheckBox();
            this.chkboxKTrue = new System.Windows.Forms.CheckBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.grpboxContinent = new System.Windows.Forms.GroupBox();
            this.rdbtnAsia = new System.Windows.Forms.RadioButton();
            this.rdbtnEurope = new System.Windows.Forms.RadioButton();
            this.rdbtnAmerica = new System.Windows.Forms.RadioButton();
            this.rrbtnAustralia = new System.Windows.Forms.RadioButton();
            this.rdbtnAfrica = new System.Windows.Forms.RadioButton();
            this.grpboxVitamin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.grpboxContinent.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblPname
            // 
            this.lblPname.BackColor = System.Drawing.Color.Transparent;
            this.lblPname.Font = new System.Drawing.Font("Microsoft Uighur", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPname.Location = new System.Drawing.Point(436, 18);
            this.lblPname.Name = "lblPname";
            this.lblPname.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblPname.Size = new System.Drawing.Size(128, 30);
            this.lblPname.TabIndex = 0;
            this.lblPname.Text = "نام خوراکی به فارسی:";
            this.lblPname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            
            // 
            // lblEname
            // 
            this.lblEname.BackColor = System.Drawing.Color.Transparent;
            this.lblEname.Font = new System.Drawing.Font("Microsoft Uighur", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEname.Location = new System.Drawing.Point(143, 16);
            this.lblEname.Name = "lblEname";
            this.lblEname.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblEname.Size = new System.Drawing.Size(128, 30);
            this.lblEname.TabIndex = 1;
            this.lblEname.Text = "نام خوراکی به انگلیسی:";
            this.lblEname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            
            // 
            // lblGoodFor
            // 
            this.lblGoodFor.BackColor = System.Drawing.Color.Transparent;
            this.lblGoodFor.Font = new System.Drawing.Font("Microsoft Uighur", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGoodFor.Location = new System.Drawing.Point(500, 62);
            this.lblGoodFor.Name = "lblGoodFor";
            this.lblGoodFor.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblGoodFor.Size = new System.Drawing.Size(64, 30);
            this.lblGoodFor.TabIndex = 2;
            this.lblGoodFor.Text = "مضر برای:";
            this.lblGoodFor.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            
            // 
            // lblBadFor
            // 
            this.lblBadFor.BackColor = System.Drawing.Color.Transparent;
            this.lblBadFor.Font = new System.Drawing.Font("Microsoft Uighur", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBadFor.Location = new System.Drawing.Point(207, 62);
            this.lblBadFor.Name = "lblBadFor";
            this.lblBadFor.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblBadFor.Size = new System.Drawing.Size(64, 30);
            this.lblBadFor.TabIndex = 3;
            this.lblBadFor.Text = "مفید برای:";
            this.lblBadFor.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            
            // 
            // txtPname
            // 
            this.txtPname.Font = new System.Drawing.Font("Microsoft Uighur", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPname.Location = new System.Drawing.Point(305, 18);
            this.txtPname.Name = "txtPname";
            this.txtPname.Size = new System.Drawing.Size(131, 30);
            this.txtPname.TabIndex = 4;
            this.txtPname.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Uighur", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(305, 62);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(196, 137);
            this.textBox2.TabIndex = 5;
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Microsoft Uighur", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(12, 62);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(196, 139);
            this.textBox3.TabIndex = 6;
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtEname
            // 
            this.txtEname.Font = new System.Drawing.Font("Microsoft Uighur", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEname.Location = new System.Drawing.Point(12, 16);
            this.txtEname.Name = "txtEname";
            this.txtEname.Size = new System.Drawing.Size(131, 30);
            this.txtEname.TabIndex = 7;
            this.txtEname.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // grpboxVitamin
            // 
            this.grpboxVitamin.BackColor = System.Drawing.Color.Transparent;
            this.grpboxVitamin.Controls.Add(this.pictureBox5);
            this.grpboxVitamin.Controls.Add(this.pictureBox4);
            this.grpboxVitamin.Controls.Add(this.pictureBox1);
            this.grpboxVitamin.Controls.Add(this.pictureBox3);
            this.grpboxVitamin.Controls.Add(this.chkboxKFalse);
            this.grpboxVitamin.Controls.Add(this.chkboxKTrue);
            this.grpboxVitamin.Controls.Add(this.chkboxEFalse);
            this.grpboxVitamin.Controls.Add(this.chkboxETrue);
            this.grpboxVitamin.Controls.Add(this.chkboxDFalse);
            this.grpboxVitamin.Controls.Add(this.chkboxDTrue);
            this.grpboxVitamin.Controls.Add(this.chkboxCFalse);
            this.grpboxVitamin.Controls.Add(this.chkboxCTrue);
            this.grpboxVitamin.Controls.Add(this.chkboxBFalse);
            this.grpboxVitamin.Controls.Add(this.chkboxAFalse);
            this.grpboxVitamin.Controls.Add(this.chkboxATrue);
            this.grpboxVitamin.Controls.Add(this.chkboxBTrue);
            this.grpboxVitamin.Controls.Add(this.lblK);
            this.grpboxVitamin.Controls.Add(this.lblE);
            this.grpboxVitamin.Controls.Add(this.lblD);
            this.grpboxVitamin.Controls.Add(this.lblC);
            this.grpboxVitamin.Controls.Add(this.lblB);
            this.grpboxVitamin.Controls.Add(this.lblA);
            this.grpboxVitamin.Font = new System.Drawing.Font("Microsoft Uighur", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpboxVitamin.Location = new System.Drawing.Point(349, 203);
            this.grpboxVitamin.Name = "grpboxVitamin";
            this.grpboxVitamin.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.grpboxVitamin.Size = new System.Drawing.Size(220, 170);
            this.grpboxVitamin.TabIndex = 8;
            this.grpboxVitamin.TabStop = false;
            this.grpboxVitamin.Text = "ویتامین";
            // 
            // lblA
            // 
            this.lblA.BackColor = System.Drawing.Color.Transparent;
            this.lblA.Font = new System.Drawing.Font("Microsoft Uighur", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblA.Location = new System.Drawing.Point(190, 63);
            this.lblA.Name = "lblA";
            this.lblA.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblA.Size = new System.Drawing.Size(22, 30);
            this.lblA.TabIndex = 1;
            this.lblA.Text = "A";
            this.lblA.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblB
            // 
            this.lblB.BackColor = System.Drawing.Color.Transparent;
            this.lblB.Font = new System.Drawing.Font("Microsoft Uighur", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblB.Location = new System.Drawing.Point(190, 93);
            this.lblB.Name = "lblB";
            this.lblB.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblB.Size = new System.Drawing.Size(22, 30);
            this.lblB.TabIndex = 2;
            this.lblB.Text = "B";
            this.lblB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblC
            // 
            this.lblC.BackColor = System.Drawing.Color.Transparent;
            this.lblC.Font = new System.Drawing.Font("Microsoft Uighur", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblC.Location = new System.Drawing.Point(190, 123);
            this.lblC.Name = "lblC";
            this.lblC.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblC.Size = new System.Drawing.Size(22, 30);
            this.lblC.TabIndex = 3;
            this.lblC.Text = "C";
            this.lblC.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblD
            // 
            this.lblD.BackColor = System.Drawing.Color.Transparent;
            this.lblD.Font = new System.Drawing.Font("Microsoft Uighur", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblD.Location = new System.Drawing.Point(71, 63);
            this.lblD.Name = "lblD";
            this.lblD.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblD.Size = new System.Drawing.Size(22, 30);
            this.lblD.TabIndex = 4;
            this.lblD.Text = "D";
            this.lblD.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblE
            // 
            this.lblE.BackColor = System.Drawing.Color.Transparent;
            this.lblE.Font = new System.Drawing.Font("Microsoft Uighur", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblE.Location = new System.Drawing.Point(71, 93);
            this.lblE.Name = "lblE";
            this.lblE.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblE.Size = new System.Drawing.Size(22, 30);
            this.lblE.TabIndex = 5;
            this.lblE.Text = "E";
            this.lblE.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblK
            // 
            this.lblK.BackColor = System.Drawing.Color.Transparent;
            this.lblK.Font = new System.Drawing.Font("Microsoft Uighur", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblK.Location = new System.Drawing.Point(71, 123);
            this.lblK.Name = "lblK";
            this.lblK.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblK.Size = new System.Drawing.Size(22, 30);
            this.lblK.TabIndex = 6;
            this.lblK.Text = "K";
            this.lblK.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chkboxBTrue
            // 
            this.chkboxBTrue.AutoSize = true;
            this.chkboxBTrue.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkboxBTrue.Location = new System.Drawing.Point(165, 92);
            this.chkboxBTrue.Name = "chkboxBTrue";
            this.chkboxBTrue.Size = new System.Drawing.Size(16, 32);
            this.chkboxBTrue.TabIndex = 9;
            this.chkboxBTrue.Text = "\r\n";
            this.chkboxBTrue.UseVisualStyleBackColor = true;
            // 
            // chkboxBFalse
            // 
            this.chkboxBFalse.AutoSize = true;
            this.chkboxBFalse.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkboxBFalse.Location = new System.Drawing.Point(128, 92);
            this.chkboxBFalse.Name = "chkboxBFalse";
            this.chkboxBFalse.Size = new System.Drawing.Size(16, 32);
            this.chkboxBFalse.TabIndex = 10;
            this.chkboxBFalse.Text = "\r\n";
            this.chkboxBFalse.UseVisualStyleBackColor = true;
            // 
            // chkboxAFalse
            // 
            this.chkboxAFalse.AutoSize = true;
            this.chkboxAFalse.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkboxAFalse.Location = new System.Drawing.Point(127, 61);
            this.chkboxAFalse.Name = "chkboxAFalse";
            this.chkboxAFalse.Size = new System.Drawing.Size(16, 32);
            this.chkboxAFalse.TabIndex = 12;
            this.chkboxAFalse.Text = "\r\n";
            this.chkboxAFalse.UseVisualStyleBackColor = true;
            // 
            // chkboxATrue
            // 
            this.chkboxATrue.AutoSize = true;
            this.chkboxATrue.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkboxATrue.Location = new System.Drawing.Point(164, 61);
            this.chkboxATrue.Name = "chkboxATrue";
            this.chkboxATrue.Size = new System.Drawing.Size(16, 32);
            this.chkboxATrue.TabIndex = 11;
            this.chkboxATrue.Text = "\r\n";
            this.chkboxATrue.UseVisualStyleBackColor = true;
            // 
            // chkboxCFalse
            // 
            this.chkboxCFalse.AutoSize = true;
            this.chkboxCFalse.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkboxCFalse.Location = new System.Drawing.Point(128, 121);
            this.chkboxCFalse.Name = "chkboxCFalse";
            this.chkboxCFalse.Size = new System.Drawing.Size(16, 32);
            this.chkboxCFalse.TabIndex = 14;
            this.chkboxCFalse.Text = "\r\n";
            this.chkboxCFalse.UseVisualStyleBackColor = true;
            // 
            // chkboxCTrue
            // 
            this.chkboxCTrue.AutoSize = true;
            this.chkboxCTrue.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkboxCTrue.Location = new System.Drawing.Point(165, 121);
            this.chkboxCTrue.Name = "chkboxCTrue";
            this.chkboxCTrue.Size = new System.Drawing.Size(16, 32);
            this.chkboxCTrue.TabIndex = 13;
            this.chkboxCTrue.Text = "\r\n";
            this.chkboxCTrue.UseVisualStyleBackColor = true;
            // 
            // chkboxDFalse
            // 
            this.chkboxDFalse.AutoSize = true;
            this.chkboxDFalse.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkboxDFalse.Location = new System.Drawing.Point(9, 61);
            this.chkboxDFalse.Name = "chkboxDFalse";
            this.chkboxDFalse.Size = new System.Drawing.Size(16, 32);
            this.chkboxDFalse.TabIndex = 16;
            this.chkboxDFalse.Text = "\r\n";
            this.chkboxDFalse.UseVisualStyleBackColor = true;
            // 
            // chkboxDTrue
            // 
            this.chkboxDTrue.AutoSize = true;
            this.chkboxDTrue.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkboxDTrue.Location = new System.Drawing.Point(46, 61);
            this.chkboxDTrue.Name = "chkboxDTrue";
            this.chkboxDTrue.Size = new System.Drawing.Size(16, 32);
            this.chkboxDTrue.TabIndex = 15;
            this.chkboxDTrue.Text = "\r\n";
            this.chkboxDTrue.UseVisualStyleBackColor = true;
            // 
            // chkboxEFalse
            // 
            this.chkboxEFalse.AutoSize = true;
            this.chkboxEFalse.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkboxEFalse.Location = new System.Drawing.Point(9, 91);
            this.chkboxEFalse.Name = "chkboxEFalse";
            this.chkboxEFalse.Size = new System.Drawing.Size(16, 32);
            this.chkboxEFalse.TabIndex = 18;
            this.chkboxEFalse.Text = "\r\n";
            this.chkboxEFalse.UseVisualStyleBackColor = true;
            // 
            // chkboxETrue
            // 
            this.chkboxETrue.AutoSize = true;
            this.chkboxETrue.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkboxETrue.Location = new System.Drawing.Point(46, 91);
            this.chkboxETrue.Name = "chkboxETrue";
            this.chkboxETrue.Size = new System.Drawing.Size(16, 32);
            this.chkboxETrue.TabIndex = 17;
            this.chkboxETrue.Text = "\r\n";
            this.chkboxETrue.UseVisualStyleBackColor = true;
            // 
            // chkboxKFalse
            // 
            this.chkboxKFalse.AutoSize = true;
            this.chkboxKFalse.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkboxKFalse.Location = new System.Drawing.Point(9, 123);
            this.chkboxKFalse.Name = "chkboxKFalse";
            this.chkboxKFalse.Size = new System.Drawing.Size(16, 32);
            this.chkboxKFalse.TabIndex = 20;
            this.chkboxKFalse.Text = "\r\n";
            this.chkboxKFalse.UseVisualStyleBackColor = true;
            // 
            // chkboxKTrue
            // 
            this.chkboxKTrue.AutoSize = true;
            this.chkboxKTrue.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkboxKTrue.Location = new System.Drawing.Point(46, 123);
            this.chkboxKTrue.Name = "chkboxKTrue";
            this.chkboxKTrue.Size = new System.Drawing.Size(16, 32);
            this.chkboxKTrue.TabIndex = 19;
            this.chkboxKTrue.Text = "\r\n";
            this.chkboxKTrue.UseVisualStyleBackColor = true;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(163, 40);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(16, 16);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 9;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(46, 40);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(16, 16);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 21;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(127, 40);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(16, 16);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 10;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(9, 40);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(16, 16);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 22;
            this.pictureBox5.TabStop = false;
            // 
            // grpboxContinent
            // 
            this.grpboxContinent.BackColor = System.Drawing.Color.Transparent;
            this.grpboxContinent.Controls.Add(this.rdbtnAfrica);
            this.grpboxContinent.Controls.Add(this.rrbtnAustralia);
            this.grpboxContinent.Controls.Add(this.rdbtnAmerica);
            this.grpboxContinent.Controls.Add(this.rdbtnEurope);
            this.grpboxContinent.Controls.Add(this.rdbtnAsia);
            this.grpboxContinent.Location = new System.Drawing.Point(226, 207);
            this.grpboxContinent.Name = "grpboxContinent";
            this.grpboxContinent.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.grpboxContinent.Size = new System.Drawing.Size(106, 166);
            this.grpboxContinent.TabIndex = 10;
            this.grpboxContinent.TabStop = false;
            this.grpboxContinent.Text = "قاره";
            // 
            // rdbtnAsia
            // 
            this.rdbtnAsia.AutoSize = true;
            this.rdbtnAsia.Font = new System.Drawing.Font("Microsoft Uighur", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnAsia.Location = new System.Drawing.Point(34, 17);
            this.rdbtnAsia.Name = "rdbtnAsia";
            this.rdbtnAsia.Size = new System.Drawing.Size(50, 32);
            this.rdbtnAsia.TabIndex = 0;
            this.rdbtnAsia.TabStop = true;
            this.rdbtnAsia.Text = "آسیا";
            this.rdbtnAsia.UseVisualStyleBackColor = true;
            // 
            // rdbtnEurope
            // 
            this.rdbtnEurope.AutoSize = true;
            this.rdbtnEurope.Font = new System.Drawing.Font("Microsoft Uighur", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnEurope.Location = new System.Drawing.Point(34, 43);
            this.rdbtnEurope.Name = "rdbtnEurope";
            this.rdbtnEurope.Size = new System.Drawing.Size(51, 32);
            this.rdbtnEurope.TabIndex = 1;
            this.rdbtnEurope.TabStop = true;
            this.rdbtnEurope.Text = "اروپا";
            this.rdbtnEurope.UseVisualStyleBackColor = true;
            // 
            // rdbtnAmerica
            // 
            this.rdbtnAmerica.AutoSize = true;
            this.rdbtnAmerica.Font = new System.Drawing.Font("Microsoft Uighur", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnAmerica.Location = new System.Drawing.Point(25, 94);
            this.rdbtnAmerica.Name = "rdbtnAmerica";
            this.rdbtnAmerica.Size = new System.Drawing.Size(59, 32);
            this.rdbtnAmerica.TabIndex = 2;
            this.rdbtnAmerica.TabStop = true;
            this.rdbtnAmerica.Text = "آمریکا";
            this.rdbtnAmerica.UseVisualStyleBackColor = true;
            // 
            // rrbtnAustralia
            // 
            this.rrbtnAustralia.AutoSize = true;
            this.rrbtnAustralia.Font = new System.Drawing.Font("Microsoft Uighur", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rrbtnAustralia.Location = new System.Drawing.Point(20, 68);
            this.rrbtnAustralia.Name = "rrbtnAustralia";
            this.rrbtnAustralia.Size = new System.Drawing.Size(65, 32);
            this.rrbtnAustralia.TabIndex = 3;
            this.rrbtnAustralia.TabStop = true;
            this.rrbtnAustralia.Text = "استرالیا";
            this.rrbtnAustralia.UseVisualStyleBackColor = true;
            // 
            // rdbtnAfrica
            // 
            this.rdbtnAfrica.AutoSize = true;
            this.rdbtnAfrica.Font = new System.Drawing.Font("Microsoft Uighur", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnAfrica.Location = new System.Drawing.Point(29, 119);
            this.rdbtnAfrica.Name = "rdbtnAfrica";
            this.rdbtnAfrica.Size = new System.Drawing.Size(55, 32);
            this.rdbtnAfrica.TabIndex = 4;
            this.rdbtnAfrica.TabStop = true;
            this.rdbtnAfrica.Text = "آفریقا";
            this.rdbtnAfrica.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(582, 440);
            this.Controls.Add(this.grpboxContinent);
            this.Controls.Add(this.grpboxVitamin);
            this.Controls.Add(this.txtEname);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.txtPname);
            this.Controls.Add(this.lblBadFor);
            this.Controls.Add(this.lblGoodFor);
            this.Controls.Add(this.lblEname);
            this.Controls.Add(this.lblPname);
            this.Name = "Form1";
            this.Text = "Project";
            this.grpboxVitamin.ResumeLayout(false);
            this.grpboxVitamin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.grpboxContinent.ResumeLayout(false);
            this.grpboxContinent.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPname;
        private System.Windows.Forms.Label lblEname;
        private System.Windows.Forms.Label lblGoodFor;
        private System.Windows.Forms.Label lblBadFor;
        private System.Windows.Forms.TextBox txtPname;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox txtEname;
        private System.Windows.Forms.GroupBox grpboxVitamin;
        private System.Windows.Forms.Label lblK;
        private System.Windows.Forms.Label lblE;
        private System.Windows.Forms.Label lblD;
        private System.Windows.Forms.Label lblC;
        private System.Windows.Forms.Label lblB;
        private System.Windows.Forms.Label lblA;
        private System.Windows.Forms.CheckBox chkboxBTrue;
        private System.Windows.Forms.CheckBox chkboxBFalse;
        private System.Windows.Forms.CheckBox chkboxKFalse;
        private System.Windows.Forms.CheckBox chkboxKTrue;
        private System.Windows.Forms.CheckBox chkboxEFalse;
        private System.Windows.Forms.CheckBox chkboxETrue;
        private System.Windows.Forms.CheckBox chkboxDFalse;
        private System.Windows.Forms.CheckBox chkboxDTrue;
        private System.Windows.Forms.CheckBox chkboxCFalse;
        private System.Windows.Forms.CheckBox chkboxCTrue;
        private System.Windows.Forms.CheckBox chkboxAFalse;
        private System.Windows.Forms.CheckBox chkboxATrue;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox grpboxContinent;
        private System.Windows.Forms.RadioButton rdbtnAfrica;
        private System.Windows.Forms.RadioButton rrbtnAustralia;
        private System.Windows.Forms.RadioButton rdbtnAmerica;
        private System.Windows.Forms.RadioButton rdbtnEurope;
        private System.Windows.Forms.RadioButton rdbtnAsia;
    }
}

